using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Ray.BiliBiliTool.Agent;
using Ray.BiliBiliTool.Application.Attributes;
using Ray.BiliBiliTool.Application.Contracts;
using Ray.BiliBiliTool.Application.Diagnostics;
using Ray.BiliBiliTool.Config.Options;
using Ray.BiliBiliTool.DomainService.Interfaces;
using Ray.BiliBiliTool.Infrastructure.Cookie;

namespace Ray.BiliBiliTool.Application;

public class Silver2CoinTaskAppService(
    ILogger<Silver2CoinTaskAppService> logger,
    IOptionsMonitor<Silver2CoinTaskOptions> silver2CoinTaskOptions,
    IAccountDomainService accountDomainService,
    ILoginDomainService loginDomainService,
    IConfiguration configuration,
    ILiveDomainService liveDomainService,
    ICoinDomainService coinDomainService,
    CookieStrFactory<BiliCookie> cookieStrFactory
)
    : BaseMultiAccountsAppService(logger, cookieStrFactory, loginDomainService, configuration),
        ISilver2CoinTaskAppService
{
    [TaskInterceptor("银瓜子兑换硬币任务", TaskLevel.One)]
    protected override async Task DoTaskAccountAsync(
        BiliCookie ck,
        CancellationToken cancellationToken = default
    )
    {
        await TaskFlowDiagnosticScope.ExecuteAsync(
            logger,
            "银瓜子兑换硬币任务",
            async () =>
            {
                if (!silver2CoinTaskOptions.CurrentValue.IsEnable)
                {
                    logger.LogInformation("已配置为关闭，跳过");
                    return;
                }

                await SetCookiesAsync(ck, cancellationToken);
                await Login(ck);

                await ExchangeSilver2Coin(ck);
            }
        );
    }

    /// <summary>
    /// 登录
    /// </summary>
    /// <returns></returns>
    [TaskInterceptor("登录")]
    private async Task Login(BiliCookie ck)
    {
        await accountDomainService.LoginByCookie(ck);
    }

    /// <summary>
    /// 直播中心的银瓜子兑换硬币
    /// </summary>
    [TaskInterceptor("银瓜子兑换硬币", rethrowWhenException: false)]
    private async Task ExchangeSilver2Coin(BiliCookie ck)
    {
        var success = await liveDomainService.ExchangeSilver2Coin(ck);
        if (!success)
            return;

        //如果兑换成功，则打印硬币余额
        var coinBalance = coinDomainService.GetCoinBalance(ck);
        logger.LogInformation("【硬币余额】 {coin}", coinBalance);
    }
}
