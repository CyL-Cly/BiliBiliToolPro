﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos.LiveApi;

public class GetLiveRoomInfoResponse
{
    public long Room_id { get; set; }

    public long Area_id { get; set; }

    public long Parent_area_id { get; set; }

    public int Live_Status { get; set; }

    public long Uid { get; set; }
}
